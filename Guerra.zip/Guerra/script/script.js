const guerras = {
  antiguidade: [
    { nome: "Guerras Médicas", periodo: "499–449 a.C.", descricao: "Conflito entre gregos e persas." },
    { nome: "Guerras Púnicas", periodo: "264–146 a.C.", descricao: "Conflito entre Roma e Cartago." }
  ],
  "idade-media": [
    { nome: "Guerras Cruzadas", periodo: "1096–1291", descricao: "Expedições militares cristãs ao Oriente Médio." },
    { nome: "Guerra dos Cem Anos", periodo: "1337–1453", descricao: "Conflito entre Inglaterra e França." }
  ],
  moderna: [
    { nome: "Guerras Napoleônicas", periodo: "1803–1815", descricao: "Conflitos liderados por Napoleão Bonaparte." },
    { nome: "Guerra Civil Americana", periodo: "1861–1865", descricao: "Conflito entre União e Estados Confederados." }
  ],
  contemporanea: [
    { nome: "Primeira Guerra Mundial", periodo: "1914–1918", descricao: "Conflito global envolvendo várias nações." },
    { nome: "Segunda Guerra Mundial", periodo: "1939–1945", descricao: "Maior conflito da história moderna." }
  ]
};

const listaGuerras = document.getElementById('guerras-lista');
const botoes = document.querySelectorAll('nav button');

function exibirGuerras(periodo) {
  listaGuerras.innerHTML = '';
  const secao = document.createElement('div');
  secao.classList.add('guerras');
  const titulo = document.createElement('h2');
  titulo.textContent = periodo.charAt(0).toUpperCase() + periodo.slice(1).replace('-', ' ');
  secao.appendChild(titulo);
  const ul = document.createElement('ul');
  guerras[periodo].forEach(guerra => {
    const li = document.createElement('li');
    li.innerHTML = `<strong>${guerra.nome}</strong> (${guerra.periodo}): ${guerra.descricao}`;
    ul.appendChild(li);
  });
  secao.appendChild(ul);
  listaGuerras.appendChild(secao);
}

botoes.forEach(botao => {
  botao.addEventListener('click', () => {
    exibirGuerras(botao.getAttribute('data-periodo'));
  });
});

// Exibir guerras da Antiguidade por padrão
exibirGuerras('antiguidade');
