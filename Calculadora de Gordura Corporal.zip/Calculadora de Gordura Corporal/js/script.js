function calcular(event) {
  event.preventDefault();

  const sexo = document.getElementById('sexo').value;
  const altura = parseFloat(document.getElementById('altura').value);
  const cintura = parseFloat(document.getElementById('cintura').value);
  const pescoco = parseFloat(document.getElementById('pescoco').value);
  const quadril = parseFloat(document.getElementById('quadril').value);

  let percentual = 0;

  if (sexo === 'masculino') {
    percentual =
      86.010 * Math.log10(cintura - pescoco) -
      70.041 * Math.log10(altura) + 36.76;
  } else {
    if (!quadril || isNaN(quadril)) {
      return alert("Por favor, preencha o campo 'Quadril' para mulheres.");
    }
    percentual =
      163.205 * Math.log10(cintura + quadril - pescoco) -
      97.684 * Math.log10(altura) - 78.387;
  }

  const resultado = document.getElementById('resultado');
  resultado.textContent = `Seu percentual de gordura corporal é: ${percentual.toFixed(2)}%`;
}

// Mostrar campo "Quadril" só para mulheres
document.getElementById('sexo').addEventListener('change', function () {
  const campoQuadril = document.getElementById('campoQuadril');
  campoQuadril.style.display = this.value === 'feminino' ? 'block' : 'none';
});

// Início com quadril oculto
document.getElementById('campoQuadril').style.display = 'none';
