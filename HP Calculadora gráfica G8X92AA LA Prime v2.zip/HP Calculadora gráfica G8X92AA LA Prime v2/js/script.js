const display = document.getElementById('display');
const canvas = document.getElementById('graphCanvas');
const ctx = canvas.getContext('2d');

function insert(value) {
    if (display.innerText === '0') {
        display.innerText = value;
    } else {
        display.innerText += value;
    }
}

function clearDisplay() {
    display.innerText = '0';
}

function deleteLast() {
    if (display.innerText.length > 1) {
        display.innerText = display.innerText.slice(0, -1);
    } else {
        display.innerText = '0';
    }
}

function calculate() {
    try {
        // Avalia a expressão exibida, cuidado com injeção no real caso de uso
        let result = eval(display.innerText);
        display.innerText = result;
    } catch {
        display.innerText = 'Erro';
    }
}

// Função para plotar gráficos 2D simples da função f(x)
function plotGraph() {
    const funcText = document.getElementById('functionInput').value;
    if (!funcText) return alert('Digite uma função para plotar');

    // Limpar canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Desenhar grade
    desenharGrade();

    ctx.beginPath();
    ctx.strokeStyle = '#0f0';
    ctx.lineWidth = 2;

    // Escala e origem no centro
    const width = canvas.width;
    const height = canvas.height;
    const xOrigin = width / 2;
    const yOrigin = height / 2;
    const scaleX = 20; // pixels por unidade x
    const scaleY = 20; // pixels por unidade y

    let firstPoint = true;
    for (let px = 0; px <= width; px++) {
        let x = (px - xOrigin) / scaleX;
        let y;
        try {
            // Avalia a função com x substituído
            y = eval(funcText);
        } catch {
            y = NaN;
        }
        if (isNaN(y) || !isFinite(y)) {
            firstPoint = true;
            continue;
        }
        let py = yOrigin - y * scaleY;

        if (firstPoint) {
            ctx.moveTo(px, py);
            firstPoint = false;
        } else {
            ctx.lineTo(px, py);
        }
    }
    ctx.stroke();
}

function desenharGrade() {
    const width = canvas.width;
    const height = canvas.height;
    const xOrigin = width / 2;
    const yOrigin = height / 2;

    ctx.strokeStyle = '#0a0';
    ctx.lineWidth = 1;

    // Linhas horizontais
    for (let y = yOrigin % 20; y < height; y += 20) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
    }

    // Linhas verticais
    for (let x = xOrigin % 20; x < width; x += 20) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
    }

    // Eixos
    ctx.strokeStyle = '#0f0';
    ctx.lineWidth = 2;

    // Eixo X
    ctx.beginPath();
    ctx.moveTo(0, yOrigin);
    ctx.lineTo(width, yOrigin);
    ctx.stroke();

    // Eixo Y
    ctx.beginPath();
    ctx.moveTo(xOrigin, 0);
    ctx.lineTo(xOrigin, height);
    ctx.stroke();
}
