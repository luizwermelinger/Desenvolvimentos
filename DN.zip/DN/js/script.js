function adicionarNome() {
  const nome = document.getElementById('nome').value.trim();

  if (nome !== '') {
    const mortes = [
      'morreu de ataque cardíaco.',
      'foi atropelado misteriosamente.',
      'desapareceu sem deixar vestígios.',
      'caiu de um prédio.',
      'foi encontrado sem vida em casa.',
      'teve uma parada respiratória.',
      'entrou em coma e nunca acordou.'
    ];

    const morteAleatoria = mortes[Math.floor(Math.random() * mortes.length)];

    const lista = document.getElementById('lista');
    const item = document.createElement('li');
    item.textContent = `nome -{morteAleatoria}`;
    lista.appendChild(item);

    document.getElementById('nome').value = '';
  }
}

function limparLista() {
  const lista = document.getElementById('lista');
  while (lista.firstChild) {
    lista.removeChild(lista.firstChild);
  }
}

function salvarLista() {
  const lista = document.getElementById('lista');
  const nomes = Array.from(lista.children).map(li => li.textContent);
  console.log('Lista salva:', nomes);
  // Você pode salvar no localStorage ou enviar para servidor se quiser
}

