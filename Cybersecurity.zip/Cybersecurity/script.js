document.getElementById("form-contato").addEventListener("submit", function (e) {
  e.preventDefault();

  const nome = document.getElementById("nome").value;
  const email = document.getElementById("email").value;
  const mensagem = document.getElementById("mensagem").value;

  // Aqui você pode adicionar a lógica para enviar o formulário, por exemplo, usando EmailJS ou outro serviço.

  document.getElementById("status").textContent = "Mensagem enviada com sucesso!";
});
