let canvas = document.getElementById('canvas');

function addRectangle() {
    let rect = document.createElement('div');
    rect.className = 'shape rectangle';
    rect.style.top = '50px';
    rect.style.left = '50px';
    canvas.appendChild(rect);
    makeDraggable(rect);
}

function addCircle() {
    let circle = document.createElement('div');
    circle.className = 'shape circle';
    circle.style.top = '50px';
    circle.style.left = '50px';
    canvas.appendChild(circle);
    makeDraggable(circle);
}

function clearCanvas() {
    canvas.innerHTML = '';
}

function makeDraggable(el) {
    el.onmousedown = function (e) {
        let offsetX = e.clientX - el.offsetLeft;
        let offsetY = e.clientY - el.offsetTop;

        function mouseMoveHandler(e) {
            el.style.left = (e.clientX - offsetX) + 'px';
            el.style.top = (e.clientY - offsetY) + 'px';
        }

        function mouseUpHandler() {
            document.removeEventListener('mousemove', mouseMoveHandler);
            document.removeEventListener('mouseup', mouseUpHandler);
        }

        document.addEventListener('mousemove', mouseMoveHandler);
        document.addEventListener('mouseup', mouseUpHandler);
    };
}

function addShape(type) {
    let shape = document.createElement('div');
    shape.className = 'shape ' + type;
    shape.style.top = '50px';
    shape.style.left = '50px';
    canvas.appendChild(shape);
    makeDraggable(shape);
}

function addSVG(type) {
    const svgNS = "http://www.w3.org/2000/svg";
    const wrapper = document.createElement('div');
    wrapper.className = 'svg-shape';
    wrapper.style.top = '50px';
    wrapper.style.left = '50px';

    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('width', '60');
    svg.setAttribute('height', '60');

    let shape;
    if (type === 'hexagon') {
        shape = document.createElementNS(svgNS, 'polygon');
        shape.setAttribute('points', '30,0 60,15 60,45 30,60 0,45 0,15');
        shape.setAttribute('fill', '#d35400');
    } else if (type === 'heart') {
        shape = document.createElementNS(svgNS, 'path');
        shape.setAttribute('d', 'M30 52 C10 32, 0 20, 30 10 C60 20, 50 32, 30 52 Z');
        shape.setAttribute('fill', '#e84393');
    }

    svg.appendChild(shape);
    wrapper.appendChild(svg);
    canvas.appendChild(wrapper);
    makeDraggable(wrapper);
}

function addSVG(type) {
  const svgNS = "http://www.w3.org/2000/svg";
  const wrapper = document.createElement('div');
  wrapper.className = 'svg-shape';
  wrapper.style.top = '50px';
  wrapper.style.left = '50px';

  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('width', '60');
  svg.setAttribute('height', '60');

  let shape;
  if (type === 'hexagon') {
    shape = document.createElementNS(svgNS, 'polygon');
    shape.setAttribute('points', '30,0 60,15 60,45 30,60 0,45 0,15');
    shape.setAttribute('fill', '#d35400');
  } else if (type === 'heart') {
    shape = document.createElementNS(svgNS, 'path');
    shape.setAttribute('d', 'M30 52 C10 32, 0 20, 30 10 C60 20, 50 32, 30 52 Z');
    shape.setAttribute('fill', '#e84393');
  } else if (type === 'pentagon') {
    shape = document.createElementNS(svgNS, 'polygon');
    shape.setAttribute('points', '30,0 58,22 47,58 13,58 2,22');
    shape.setAttribute('fill', '#2980b9');
  }

  svg.appendChild(shape);
  wrapper.appendChild(svg);
  canvas.appendChild(wrapper);
  makeDraggable(wrapper);
}

function exportarImagem() {
  html2canvas(document.getElementById("canvas")).then(canvas => {
    const link = document.createElement("a");
    link.download = "projeto.png";
    link.href = canvas.toDataURL("image/png");
    link.click();
  });
}
