document.addEventListener('DOMContentLoaded', () => {
  const botaoCarrinho = document.querySelector('.botao-carrinho');

  botaoCarrinho.addEventListener('click', () => {
    alert('Produto adicionado ao carrinho!');
    // Você pode expandir isso salvando no localStorage:
    const produto = {
      nome: 'Nike Air Zoom',
      preco: 799,
      imagem: document.querySelector('.imagem-tenis').src
    };

    let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    carrinho.push(produto);
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
  });
});
