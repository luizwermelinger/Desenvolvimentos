let display = document.getElementById('display');

function inserir(valor) {
    if (display.innerText === '0') {
        display.innerText = valor;
    } else {
        display.innerText += valor;
    }
}

function limpar() {
    display.innerText = '0';
}

function apagar() {
    display.innerText = display.innerText.slice(0, -1);
    if (display.innerText === '') {
        display.innerText = '0';
    }
}

function calcular() {
    try {
        display.innerText = eval(display.innerText);
    } catch {
        display.innerText = 'Erro';
    }
}

function funcaoCientifica(funcao) {
    try {
        let valor = eval(display.innerText);
        if (funcao === 'Math.log10') {
            display.innerText = Math.log10(valor);
        } else if (funcao === 'Math.exp') {
            display.innerText = Math.exp(valor);
        } else {
            display.innerText = eval(funcao({ valor }));
        }
    } catch {
        display.innerText = 'Erro';
    }
}
